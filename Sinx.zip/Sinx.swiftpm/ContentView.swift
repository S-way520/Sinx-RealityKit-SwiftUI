import SwiftUI
import RealityKit
struct ContentView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}
struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let anchorEntity = AnchorEntity(plane: .horizontal)
        for siny in 0..<15 {
            let sphereEntity = ModelEntity(mesh: MeshResource.generateSphere(radius: 0.2 / 10), materials: [SimpleMaterial(color: .red, isMetallic: false)])
            let x = Float(siny) * 0.05
            sphereEntity.position.x = x
            anchorEntity.addChild(sphereEntity)
            arView.scene.addAnchor(anchorEntity)
            Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { _ in
                let date = Date().timeIntervalSince1970
                let sinValue = 0.1 * sin(3 * date - Double(siny) / 2)
                sphereEntity.position.y = Float(sinValue)
            }
        }
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {}
}
